-- خانات البانر (نص + صورة) والنص الجديد "شريكك في النمو"
alter table public.site_settings add column if not exists banner_title_ar text;
alter table public.site_settings add column if not exists banner_title_en text;
alter table public.site_settings add column if not exists banner_line1_ar text;
alter table public.site_settings add column if not exists banner_line1_en text;
alter table public.site_settings add column if not exists banner_line2_ar text;
alter table public.site_settings add column if not exists banner_line2_en text;
alter table public.site_settings add column if not exists banner_button_ar text;
alter table public.site_settings add column if not exists banner_button_en text;
alter table public.site_settings add column if not exists banner_image_url text;

update public.site_settings set
  banner_title_ar  = coalesce(nullif(banner_title_ar, ''), 'شريكك في النمو'),
  banner_line1_ar  = coalesce(nullif(banner_line1_ar, ''), 'نوفيدا للاستثمار والتكنولوجيا.. خبرة في إدارة الاستثمارات وتنميتها عبر قطاعات متعددة،'),
  banner_line2_ar  = coalesce(nullif(banner_line2_ar, ''), 'تواصل معنا لتتعرف على فرص الشراكة والاستثمار مع المجموعة.'),
  banner_button_ar = coalesce(nullif(banner_button_ar, ''), 'تواصل معنا'),
  banner_title_en  = coalesce(nullif(banner_title_en, ''), 'Your Partner in Growth'),
  banner_line1_en  = coalesce(nullif(banner_line1_en, ''), 'Novida Investment & Technology: expertise in managing and growing investments across multiple sectors.'),
  banner_line2_en  = coalesce(nullif(banner_line2_en, ''), 'Contact us to explore partnership and investment opportunities with the group.'),
  banner_button_en = coalesce(nullif(banner_button_en, ''), 'Contact us');

select banner_title_ar as "العنوان", banner_line1_ar as "السطر الأول" from public.site_settings;
